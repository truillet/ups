#include <stdio.h>
#include <stdlib.h>
#include "../include/pile.h"

#define LIGNES 70
#define COLONNES 30

typedef struct Pas{
    //Coord départ
    int x;
    int y;
    //Coord arrivée
    int z;
    int t;
}Pas_s;

typedef struct Pile{
    Pas tab[LIGNES*COLONNES];
    int taille;
}Pile_s;

Pas new_pas(int x, int y, int z, int t){
    Pas pas;
    pas = (Pas)malloc(sizeof(Pas_s));
    pas->x=x;
    pas->y=y;
    pas->z=z;
    pas->t=t;
    return pas;
}

Pile cree_pile(){
    Pile pile;
    pile = (Pile)malloc(sizeof(Pile_s));
    pile->taille=0;
    return pile;
}

void depile(Pile pile){
    if(getSize(pile) != 0){
        pile->taille--;
    }
}

void empile(Pile pile,Pas new_pas){
    pile->tab[getSize(pile)] = new_pas;
    pile->taille++;
}

int getSize(Pile pile){
    return pile->taille;
}