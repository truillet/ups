#ifndef __ARBRE__H__
#define __ARBRE__H__

 #include <stdbool.h>

typedef struct s_arbre* Arbre;

Arbre creer_arbre();
void ajouter(int, Arbre);
bool trouver(int, Arbre);
void supprimer(Arbre);

#endif