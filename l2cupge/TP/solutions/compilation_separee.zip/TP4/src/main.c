#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "../include/maLibMath.h"

int main (int argc, char * argv[]){
    printf("Point 1\n");
    Point pt1 = Demande_Point();
    printf("Point 2\n");
    Point pt2 = Demande_Point();
    printf("Point 3\n");
    Point pt3 = Demande_Point();

    //Centre de Gravité du Triangle
    Point G = Creer_Point((getX(pt1) + getX(pt2) + getX(pt3))/3,(getY(pt1) + getY(pt2) + getY(pt3))/3,(getZ(pt1) + getZ(pt2) + getZ(pt3))/3);
    Affiche_Point(G);

    //Aire du triangle
    float aera = (Norme(Produit_Vectoriel(Vectorise(pt1,pt2),Vectorise(pt1,pt3))))/2;
    printf("Aire du triangle : %.2f\n",aera);

    //Perimetre du triangle
    float perim = Norme(Vectorise(pt1,pt2)) + Norme(Vectorise(pt2,pt3)) + Norme(Vectorise(pt3,pt1));
    printf("Perimetre du triangle : %.2f\n",perim);

    Equation Eq = Equation_Plan(pt1,pt2,pt3);
    Affiche_Equation_Plan(Eq);

    return 0;
}