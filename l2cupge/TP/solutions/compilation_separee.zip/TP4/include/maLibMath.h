/*
*   Librairie maPileMath.h
*/

//Pointeur sur les structures Point, Vecteur et Equation
typedef struct Point * Point;
typedef struct Vecteur * Vecteur;
typedef struct Equation * Equation;

//Getter
float getX(Point p);
float getY(Point p);
float getZ(Point p);

//Demande les coords du point
Point Demande_Point();

//Création du point
Point Creer_Point(float x, float y, float z);

//Création du vecteur
Vecteur Vectorise(Point Pt1, Point Pt2);

//Affiche Vecteur
void Affiche_Vecteur(Vecteur v);

//Affiche Point
void Affiche_Point(Point pt);

//Produit Vectoriel
Vecteur Produit_Vectoriel(Vecteur V1, Vecteur V2);

//Produit Scalaire
float Produit_Scalaire(Vecteur V1, Vecteur V2);

//Norme
float Norme(Vecteur V);

//Renvoie l'équation du plan
Equation Equation_Plan(Point Pt1, Point Pt2, Point Pt3);

//Affiche l'équation
void Affiche_Equation_Plan(Equation Eq);