package l3difs;

public class helloService {
    public String message() {
        return("Bonjour le monde");
    }
}
