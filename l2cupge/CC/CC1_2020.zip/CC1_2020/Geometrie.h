/* Geometrie.h */

#ifndef __GEOMETRIE_H__
#define __GEOMETRIE_H__

typedef struct {
	float x;
	float y;
} Point2D;

typedef struct {
	float vx;
	float vy;
} Vecteur2D;

typedef struct{
	Point2D center;
	Vecteur2D direction;
} Circle;

 
Point2D creerPoint(float,float);
Vecteur2D creerVecteur(Point2D, Point2D);
void affiche(Point2D);
Circle creerCercle(Point2D, Vecteur2D);
float aire(Circle);

#endif
