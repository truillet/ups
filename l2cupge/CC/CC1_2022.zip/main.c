#include <stdio.h>
#include "quaternion.h"


int main(int argc, char *argv[]) {
    Quaternion q = quaternion(1,5,-2,3);

    printf("\nQuaternion q : \n");
    affiche_quaternion(q);

    Quaternion qb = conjugue(q);
    printf("\nConjugue de q : \n");
    affiche_quaternion(qb);
    Quaternion qi=inverse(q);

    printf("\nInverse de q : \n");
    affiche_quaternion(qi);
    
    printf("\nNorme : %.2f\n", norme(q));
    return 0;
}