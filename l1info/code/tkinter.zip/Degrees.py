#! /usr/bin/python
# -*- coding: utf8 -*-
#
# Degrees.py

from tkinter import *

# define a class to store any type of named data
class Data(object):
    pass # do nothing
  

def celcius_to_fahrenheit():
    global myData
    #Convert the value from Celcius to Fahrenheit and insert the result into lbl_result.
    celcius = myData.window.ent_temperature.get()
    fahrenheit = (float(celcius) * 9/5) + 32
    myData.window.lbl_result["text"] = f"{round(fahrenheit, 2)} F"


def main():
    global myData
    
    window = Tk(); # get the root window
    window.title("Temperature converter")
    
    frm_entry = Frame(master=window)
    ent_temperature = Entry(master=frm_entry, width=10)
    lbl_temp = Label(master=frm_entry, text="°C")
    
    ent_temperature.grid(row=0, column=0, sticky="e")
    lbl_temp.grid(row=0, column=1, sticky="w")

    # Create the conversion Button and result display Label
    btn_convert = Button(
            master=window,
            text="\N{RIGHTWARDS BLACK ARROW}",
            command=celcius_to_fahrenheit)
    lbl_result = Label(master=window, text="F")

    # Set-up the layout using the .grid() geometry manager
    frm_entry.grid(row=0, column=0, padx=10)
    btn_convert.grid(row=0, column=1, pady=10)
    lbl_result.grid(row=0, column=2, padx=10)
    
    myData=Data() # build a new Data object
    myData.window = window  # I need root later to destroy the window for instance
    myData.window.ent_temperature = ent_temperature
    myData.window.lbl_result = lbl_result
    
    window.mainloop() # start the mainloop

    
# launch main
if __name__ == '__main__':
    main()