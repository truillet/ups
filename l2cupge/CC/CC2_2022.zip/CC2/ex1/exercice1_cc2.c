#include <stdio.h>

float suite(int);

float suite(int n) {
    switch(n){
        case 1:
            return 1; // U1=1
        case 2:
            return 2; // U2=2
        default:
            return ((2*suite(n-1)+suite(n-2))/2); // Un=(2U(n-1)+U(n-2))/2
    }
}

int main(int argc, char *argv[]) {
    // entrer une valeur limite
    int limite;
    printf("Entrer une valeur limite: ");
    scanf("%d", &limite);
    int i=1;
    while (suite(i)<=limite)     {
        printf("U(%d) >> %.2f\n", i, suite(i));
        i++;
    }
}