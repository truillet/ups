#! /usr/bin/python
# -*- coding: utf8 -*-
#
# Button2.py

from tkinter import *

def buttonPressed():
    print("Button was pressed")
    
def main():
    root = Tk(); # get the root window
    root.geometry("200x50")
    root.grid(); # use the grid layout manager
    
    # define a label and put it on the root window
    myLabel = Label(root, text="Hello world")
    myLabel.grid(row=0, column=0) # put the label on the grid
    # create a button
    myButton = Button(root, text="Quit", command=buttonPressed)
    myButton.grid(row=0, column=1)
    root.mainloop() # start the mainloop
    
# launch main
if __name__ == '__main__':
    main()
    