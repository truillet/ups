#include <stdio.h>
#include <stdlib.h>
#include <time.h>     
#include <ctype.h>  
#include "../include/pile.h"

#define FERME 0
#define OUVERT 1
#define LIGNES 70
#define COLONNES 30

//Labyrinthe
char petitlab[LIGNES][COLONNES] =
    {{FERME, OUVERT, FERME, FERME, FERME, FERME},
    {FERME, OUVERT, OUVERT, OUVERT, OUVERT, FERME},
    {FERME, OUVERT, FERME, FERME, FERME, FERME},
    {FERME, OUVERT, OUVERT, OUVERT, OUVERT, FERME},
    {FERME, FERME, FERME, FERME, OUVERT, FERME}} ;


void affiche_laby(char (*laby)[COLONNES]){
    for (int i=0; i<LIGNES; i++){
        for (int j=0; j<COLONNES; j++){
            switch((int)laby[i][j]){
                case FERME: //FERME
                    printf("X");
                    break;
                case OUVERT: //OUVERT
                    printf(" ");
                    break;
            }
        }
        printf("\n");
    }
}

void creation_laby(char (*laby)[COLONNES]){
    for (int i=0; i<LIGNES; i++){
        for (int j=0; j<COLONNES; j++){
            if ((rand()%10 <= 4) || (i==0 && j==1) || (i==1 && j==1)){
                laby[i][j] = OUVERT;
            }else{
                laby[i][j] = FERME;
            }
            if((i==0 && j!=1) || (j==0) || (j==COLONNES-1)){
                laby[i][j] = FERME;
            }
        }
    }
}

int main (int argc, char * argv[]){
    srand(time(NULL));
    char laby[LIGNES][COLONNES];

    char yes_or_not = 'n';

    while (toupper(yes_or_not) != 'Y'){
        creation_laby(laby);
        affiche_laby(laby);

        printf("\n[Y/n]\n");
        scanf("%c",&yes_or_not);
        fflush(stdin);
     }
    
    printf("OK\n");
    
    Pile pile = cree_pile();
    Pas pas_act = new_pas(0,1,1,1);
    empile(pile,pas_act);

    return 0;
}