#! /usr/bin/python
# -*- coding: utf8 -*-
#
# Label_Entry.py

from tkinter import *

def main():
    window = Tk(); # get the root window
    window.grid(); # use the grid layout manager
    
    # define a label and put it on the root window
    label = Label(window, text="Nom")
    entry = Entry(window, width=50, bg='#138D75')
    
    label.grid() # put the label on the grid
    entry.grid() #put the entry on the grid
    window.mainloop() # start the mainloop
    
# launch main
if __name__ == '__main__':
    main()
    