/*
*   Librairie pile.h
*/

typedef struct Pas * Pas;
typedef struct Pile * Pile;


Pas new_pas(int x, int y, int z, int t);
Pile cree_pile();

void depile(Pile pile);

void empile(Pile pile,Pas new_pas);

int getSize(Pile pile);