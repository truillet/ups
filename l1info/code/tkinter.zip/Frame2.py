#! /usr/bin/python
# -*- coding: utf8 -*-
#
# Frame1.py

from tkinter import *

def main():
    window = Tk(); # get the root window
    f1 = Frame(master=window, width=100, height=100, bg='red')
    f2 = Frame(master=window, width=50, height=50, bg='yellow')
    f3 = Frame(master=window, width=25, height=25, bg='blue')
    
    # pack places each Frame in the order assigned to the window
    f1.place(x=0,y=0)
    f2.place(x=70,y=25)
    f3.place(x=20,y=10)
    window.mainloop() # start the mainloop
    
# launch main
if __name__ == '__main__':
    main()