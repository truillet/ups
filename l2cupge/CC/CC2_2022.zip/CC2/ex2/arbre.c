#include "arbre.h"
#include <malloc.h>

typedef struct s_cellule* Cellule;

struct s_cellule {
    int val;
    Arbre fg;
    Arbre fd;
};

struct s_arbre {
    Cellule racine;
};

Arbre creer_arbre() {
    Arbre a = malloc(sizeof(struct s_arbre));
    a->racine = NULL;
    return a;
}

void ajouter(int v, Arbre a){
    // si l'arbre est vide, on crée une cellule avec la valeur v
    if(a->racine == NULL){
        Cellule c = malloc(sizeof(struct s_cellule));
        c->val = v;
        c->fg = malloc(sizeof(struct s_arbre));
        c->fg->racine = NULL;
        c->fd = malloc(sizeof(struct s_arbre));
        c->fd->racine = NULL;
        a->racine = c;
    }
    // i l'arbre n'est pas vide
    else { 
        if(v <= a->racine->val){
            ajouter(v, a->racine->fg);
        }
        else {
            ajouter(v, a->racine->fd);
        }    
    }
}

bool trouver(int v, Arbre a){
    // comparer la valeur avec la racine et explorer l'arbre
    if (a->racine == NULL) {
        return false;
    }
    else 
        if (a->racine->val == v) {
        return true;
        }
        else if (v < a->racine->val) {
            return trouver(v, a->racine->fg);
        }
        else {
            return trouver(v, a->racine->fd);
        }
}

void supprimer(Arbre a){
    // parcourir l'arbre jusqu'aux feuilles et libérer les cellules
    if (a->racine != NULL) {
        supprimer(a->racine->fg);
        supprimer(a->racine->fd);
        free(a->racine);
    }
}
