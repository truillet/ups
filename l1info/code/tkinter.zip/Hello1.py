#! /usr/bin/python
# -*- coding: utf8 -*-
#
# Hello1.py

from tkinter import *

def main():
    root = Tk(); # get the root window
    root.grid(); # use the grid layout manager
    
    # define a label and put it on the root window
    myLabel = Label(root, text="Hello world",
                    foreground="orange", # Set the text color to orange
                    background="#1ABC9C") # Set the background color to hexa color
    # https://htmlcolorcodes.com
    
    myLabel.grid() # put the label on the grid
    print("launch mainloop")
    root.mainloop() # start the mainloop
    
# launch main
if __name__ == '__main__':
    print("launch main function")
    main()
    