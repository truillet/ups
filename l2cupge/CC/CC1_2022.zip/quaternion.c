#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "quaternion.h"

/* structures */
struct s_real_quaternion {
    float a;
};

struct s_imag_quaternion {
    float b;
    float c;
    float d;
};

struct s_quaternion {
    RealQuaternion real;
    ImagQuaternion imag;
};

/* constructeur */
Quaternion quaternion(int a, int b, int c, int d) {
    Quaternion q=(Quaternion) malloc(sizeof(struct s_quaternion));
    RealQuaternion real=(RealQuaternion) malloc(sizeof(struct s_real_quaternion));
    q->real=real;
    ImagQuaternion imag=(ImagQuaternion) malloc(sizeof(struct s_imag_quaternion));
    q->imag=imag;

    q->real->a = a;
    q->imag->b = b;
    q->imag->c = c;
    q->imag->d = d;
    return q;
}

/* parties réelles et imaginaires des quaternions */
RealQuaternion Re(Quaternion q){
    return (q->real);
}

ImagQuaternion Im(Quaternion q){
    return (q->imag);
}

/* opérateurs */
float norme(Quaternion q){
    return (sqrt(q->real->a*q->real->a + q->imag->b*q->imag->b + q->imag->c*q->imag->c + q->imag->d*q->imag->d));
}

Quaternion conjugue(Quaternion q){
    q->imag->b = -q->imag->b;
    q->imag->c = -q->imag->c;
    q->imag->d = -q->imag->d;
    return(q);
}

Quaternion inverse(Quaternion q){
    /* q doit être non nul */
    assert(q->real->a != 0);

    float norme_q_carre = norme(q)*norme(q);
    q->real->a = (q->real->a)/norme_q_carre;
    q->imag->b = -(q->imag->b)/norme_q_carre;
    q->imag->c = -(q->imag->c)/norme_q_carre;
    q->imag->d = -(q->imag->d)/norme_q_carre;
    return(q);
}

/* affiche un quaternion */
void affiche_quaternion(Quaternion q){
    printf("%.2f + (%.2f)i + (%.2f)j + (%.2f)k\n", q->real->a, q->imag->b, q->imag->c, q->imag->d);
}