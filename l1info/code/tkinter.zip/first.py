from tkinter import *

window = Tk()
label = Label(window, text="Bonjour le monde")
bouton = Button(window,text="ok")

label.pack()
bouton.pack()
window.mainloop()