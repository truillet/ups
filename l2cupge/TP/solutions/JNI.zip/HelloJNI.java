package fr.ut3;

class HelloJNI {
	static {
		System.loadLibrary("Greetings");
	} // librairie native
	
	public static native String getGreetings(String who);
	public static void main(String[] args) {
		HelloJNI h = new HelloJNI();
		System.out.println(getGreetings(args[0]));
	}
}

