// Greetings.c
#include <jni.h>
#include "fr_ut3_HelloJNI.h"

JNIEXPORT jstring JNICALL Java_fr_ut3_HelloJNI_getGreetings(JNIEnv* env, jclass obj, jstring string) {
	const char* str = (*env)->GetStringUTFChars(env,string,0);
	char cap[128];
	// strcpy(cap, str);
	sprintf(cap, "You welcome, %s\n", str);
	(*env)->ReleaseStringUTFChars(env, string, str);
	return ((*env)->NewStringUTF(env, cap));
}
