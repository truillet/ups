#! /usr/bin/python
# -*- coding: utf8 -*-
#
# Button3.py

from tkinter import *

# define a class to store any type of named data
class Data(object):
    pass # do nothing
    
def buttonPressed():
    global myData
    print("Button was pressed")
    myData.root.destroy()
    
def main():
    global myData
    root = Tk(); # get the root window
    root.geometry("200x50")
    root.grid(); # use the grid layout manager
    
    # define a label and put it on the root window
    myLabel = Label(root, text="Hello world")
    myLabel.grid(row=0, column=0) # put the label on the grid
    # create a button
    myButton = Button(root, text="Quit", command=buttonPressed)
    myButton.grid(row=0, column=1)
    
    myData=Data() # build a new Data object
    myData.root = root  # I need root later to destroy the window
    root.mainloop() # start the mainloop
    
# launch main
if __name__ == '__main__':
    main()
    