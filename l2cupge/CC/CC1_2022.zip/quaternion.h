#ifndef __QUATERNION_H__
#define __QUATERNION_H__

typedef struct s_real_quaternion *RealQuaternion;
typedef struct s_imag_quaternion *ImagQuaternion;
typedef struct s_quaternion *Quaternion; 


/* constructeur */
Quaternion quaternion();
/* parties réelles et imaginaires des quaternions */
RealQuaternion Re(Quaternion q);
ImagQuaternion Im(Quaternion q);

/* opérateurs */
float norme(Quaternion q);
Quaternion conjugue(Quaternion q);
Quaternion inverse(Quaternion q);

/* affiche un quaternion */
void affiche_quaternion(Quaternion q);
#endif