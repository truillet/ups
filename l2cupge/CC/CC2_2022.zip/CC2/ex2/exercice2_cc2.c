#include <stdio.h>
#include "arbre.h"

int main (int argc, char *argv[]) {
    int tab[] = {12, 8, 4, 9, 24, 20, 13};

    Arbre a = creer_arbre();
    for (int i = 0; i < 7; i++) {
        printf("Ajout de la valeur %d à l'arbre\n", tab[i]);
        ajouter(tab[i], a);
    }

    printf("Trouver la valeur 20 = %d\n",trouver(20, a));
    printf("Trouver la valeur 30 = %d\n",trouver(30, a));
    supprimer(a);
}

