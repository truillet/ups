/* Geometrie.c */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Geometrie.h"

#define PI 3.141592


Point2D creerPoint(float x, float y){
	Point2D p;
	p.x = x;
	p.y = y;
	return(p);
}

Vecteur2D creerVecteur(Point2D A, Point2D B) {
	Vecteur2D AB;
	AB.vx = B.x - A.x;
	AB.vy = B.y - A.y;
	return(AB);
}

void affiche(Point2D p){
	printf("Point (%.2f,%.2f)\n", p.x, p.y);
}

Circle creerCercle(Point2D p, Vecteur2D v) {
	Circle c;
	c.center=p;
	c.direction=v;
	return(c);
}

float aire(Circle c) {
	float r = sqrt((c.direction.vy)*(c.direction.vy) - (c.direction.vx)*(c.direction.vx));
	return(PI*r*r);
}

int main(int argc, char* argv[]) {

	if (argc!=5) {
		printf("Wrong usage, 4 parameters expected: ./a x y vx vy\n");
		return(EXIT_FAILURE); // ERROR
	}
	// vérification des arguments
	int i=1;
	float origin;
	while (i<argc) {
	// normalement, il faudrait vérifier que les données sont ok
		if (sscanf(argv[i], "%f", &origin) != 1) {
			printf("Error, %s is not a float\n", argv[i]);
			return(EXIT_FAILURE);
		}
		i++;
	}
	float x = atof(argv[1]);
	float y = atof(argv[2]);
	float vx = atof(argv[3]);
	float vy = atof(argv[4]);

	// affectation des arguments
	
	Point2D P= creerPoint(x,y);

	Vecteur2D V;
	V.vx=vx;
	V.vy=vy;
	affiche(P);
	affiche(P); // once again, not useful ...
 
	Circle c = creerCercle(P,V);
	float a = aire(c);
	printf("l'aire est de %.2f\n",a);
	return(0);
}
